import GoRemajaMockup from "./GoRemajaMockup";

function App() {
  return <GoRemajaMockup />;
}

export default App;
