import { Search } from "lucide-react";
import { useState } from "react";
import QuizZone from "./features/quiz/QuizZone";

export default function GoRemajaMockup() {
  const [page, setPage] = useState('home');
  return (
    <div className="min-h-screen bg-gradient-to-b from-pink-100 via-white to-blue-100 p-6">
      {/* Header */}
      <header className="flex justify-between items-center mb-6">
        <h1 className="text-2xl font-bold text-pink-600">GO Remaja</h1>
        <nav className="space-x-4 text-gray-700">
          <button onClick={()=>setPage("home")} className="hover:text-pink-600">Home</button>
          <a href="#" className="hover:text-pink-600">Artikel</a>
          <button onClick={()=>setPage("kuis")} className="hover:text-pink-600">Kuis</button>
          <a href="#" className="hover:text-pink-600">Konsultasi</a>
          <a href="#" className="hover:text-pink-600">My Space</a>
        </nav>
      </header>

      {/* Search */}
      <div className="flex items-center max-w-md mx-auto mb-6">
        <input
          placeholder="Cari artikel..."
          className="flex-1 rounded-l-full border px-4 py-2"
        />
        <button className="rounded-r-full bg-pink-500 hover:bg-pink-600 px-4 py-2 text-white">
          <Search size={18} />
        </button>
      </div>

      {/* Content */}
      {page === 'home' ? (
        <div className="max-w-3xl mx-auto text-gray-700">
          <div className="bg-white rounded-2xl shadow p-6 border">
            <h2 className="text-xl font-semibold mb-2">Selamat datang di GO Remaja</h2>
            <p>Jelajahi artikel, konsultasi, dan coba fitur <span className='font-semibold'>Kuis</span> untuk belajar seru!</p>
          </div>
        </div>
      ) : (
        <QuizZone />
      )}
    </div>
  );
}
