
import { useState } from "react";
import { motion } from "framer-motion";

/**
 * QuizZone - Komponen kuis & gamifikasi untuk GO Remaja.
 * Cara pakai: import QuizZone dan render <QuizZone /> di mana saja (misal di menu "Kuis").
 */
export default function QuizZone() {
  const avatars = ["🐧", "🐱", "🐶", "🐰", "🐼", "🐨", "🦊", "🐯"];

  const questions = [
    { question: "Berapa jam tidur ideal untuk remaja per hari?", options: ["4-5 jam","6-8 jam","8-10 jam",">10 jam"], answer: 2 },
    { question: "Makanan apa yang paling sehat untuk sarapan?", options: ["Donat + kopi","Nasi goreng berminyak","Buah + oatmeal","Mi instan"], answer: 2 },
    { question: "Berapa gelas air putih yang dianjurkan setiap hari?", options: ["2-3 gelas","4-5 gelas","6-8 gelas",">10 gelas"], answer: 2 },
    { question: "Olahraga ideal untuk remaja minimal berapa kali seminggu?", options: ["1x","2x","3x atau lebih","Tidak perlu"], answer: 2 },
  ];

  const [current, setCurrent] = useState(0);
  const [score, setScore] = useState(0);
  const [finished, setFinished] = useState(false);
  const [badges, setBadges] = useState([]);
  const [leaderboard, setLeaderboard] = useState([]);
  const [selectedAvatar, setSelectedAvatar] = useState(null);

  const getRandomAvatar = () => avatars[Math.floor(Math.random() * avatars.length)];

  const handleAnswer = (index) => {
    if (index === questions[current].answer) setScore((s) => s + 1);
    const next = current + 1;
    if (next < questions.length) {
      setCurrent(next);
    } else {
      const finalScore = (index === questions[current].answer) ? score + 1 : score;
      setFinished(true);
      awardBadge(finalScore);
      updateLeaderboard(finalScore);
    }
  };

  const awardBadge = (finalScore) => {
    let earned = [];
    if (finalScore === questions.length) earned.push({ label: "🏆 Master Sehat", desc: "Menjawab semua benar!" });
    else if (finalScore >= 3) earned.push({ label: "🌟 Pahlawan Sehat", desc: "Sudah paham banyak, hebat!" });
    else if (finalScore >= 1) earned.push({ label: "💡 Pemula Sehat", desc: "Awal yang baik, terus belajar!" });
    else earned.push({ label: "📚 Mulai Belajar", desc: "Yuk coba lagi kuisnya!" });
    setBadges(earned);
  };

  const updateLeaderboard = (finalScore) => {
    const newEntry = { name: `User ${leaderboard.length + 1}`, score: finalScore, avatar: selectedAvatar || getRandomAvatar() };
    const updated = [...leaderboard, newEntry].sort((a,b)=>b.score-a.score).slice(0,5);
    setLeaderboard(updated);
  };

  const progress = ((current + (finished ? 1 : 0)) / questions.length) * 100;

  if (!selectedAvatar) {
    return (
      <div className="min-h-[60vh] flex items-center justify-center p-4">
        <motion.div initial={{ opacity: 0, y: 50 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5 }}
          className="bg-white rounded-2xl shadow p-6 w-full max-w-md text-center border">
          <h2 className="text-2xl font-bold mb-4 text-purple-700">Pilih Avatar Kamu</h2>
          <div className="grid grid-cols-4 gap-4">
            {avatars.map((av, i) => (
              <motion.button key={i} whileTap={{ scale: 0.9 }} onClick={() => setSelectedAvatar(av)}
                className="text-3xl p-3 rounded-xl bg-purple-100 hover:bg-purple-300">
                {av}
              </motion.button>
            ))}
          </div>
        </motion.div>
      </div>
    );
  }

  return (
    <div className="p-4">
      <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.4 }}
        className="bg-white rounded-2xl shadow p-6 w-full max-w-2xl mx-auto border">
        {/* Progress Bar */}
        <div className="w-full bg-gray-200 rounded-full h-3 mb-6 overflow-hidden">
          <motion.div className="bg-purple-500 h-3" initial={{ width: 0 }} animate={{ width: `${progress}%` }} transition={{ duration: 0.5 }} />
        </div>

        {!finished ? (
          <div key={current}>
            <h2 className="text-xl font-semibold mb-4 text-purple-700">{questions[current].question}</h2>
            <div className="grid gap-3">
              {questions[current].options.map((opt, i) => (
                <motion.button key={i} whileTap={{ scale: 0.97 }} onClick={() => handleAnswer(i)}
                  className="w-full bg-purple-100 hover:bg-purple-300 text-purple-800 font-medium py-2 px-4 rounded-xl shadow">
                  {opt}
                </motion.button>
              ))}
            </div>
            <p className="text-gray-500 text-sm mt-4">Pertanyaan {current + 1} dari {questions.length}</p>
          </div>
        ) : (
          <div className="text-center">
            <h2 className="text-2xl font-bold mb-4">🎉 Kuis Selesai!</h2>
            <p className="text-lg mb-2">
              Skor kamu: <span className="font-bold">{score}</span> / {questions.length}
            </p>

            {badges.length > 0 && (
              <div className="mt-4">
                {badges.map((badge, i) => (
                  <motion.div key={i} initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.2 * i }}
                    className="bg-yellow-100 border border-yellow-300 rounded-xl p-3 mb-3">
                    <p className="text-xl">{badge.label}</p>
                    <p className="text-sm text-gray-600">{badge.desc}</p>
                  </motion.div>
                ))}
              </div>
            )}

            {/* Leaderboard */}
            {leaderboard.length > 0 && (
              <div className="mt-6 text-left">
                <h3 className="text-lg font-semibold mb-2 text-purple-700">🏅 Leaderboard</h3>
                <ul className="space-y-2">
                  {leaderboard.map((entry, i) => (
                    <li key={i} className="flex justify-between items-center bg-gray-100 rounded-lg p-2">
                      <span>{entry.avatar} {i + 1}. {entry.name}</span>
                      <span className="font-bold">{entry.score}</span>
                    </li>
                  ))}
                </ul>
              </div>
            )}

            <motion.button whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}
              onClick={() => { window.scrollTo(0,0); location.hash = '#/kuis'; }}
              className="mt-6 bg-blue-500 hover:bg-blue-600 text-white py-2 px-6 rounded-xl shadow">
              Main Lagi
            </motion.button>
          </div>
        )}
      </motion.div>
    </div>
  );
}
