import { useState } from "react";

export default function BMI() {
  const [berat, setBerat] = useState("");
  const [tinggi, setTinggi] = useState("");
  const [hasil, setHasil] = useState(null);

  const hitungBMI = () => {
    if (!berat || !tinggi) return;
    const tinggiMeter = tinggi / 100;
    const bmi = (berat / (tinggiMeter * tinggiMeter)).toFixed(1);

    let kategori = "";
    if (bmi < 18.5) kategori = "Kurus";
    else if (bmi < 24.9) kategori = "Normal";
    else if (bmi < 29.9) kategori = "Gemuk";
    else kategori = "Obesitas";

    setHasil({ bmi, kategori });
  };

  return (
    <div className="p-6">
      <h1 className="text-2xl font-bold mb-4">Kalkulator BMI</h1>
      <div className="flex flex-col gap-3 max-w-sm">
        <input
          type="number"
          placeholder="Berat (kg)"
          value={berat}
          onChange={(e) => setBerat(e.target.value)}
          className="border rounded p-2"
        />
        <input
          type="number"
          placeholder="Tinggi (cm)"
          value={tinggi}
          onChange={(e) => setTinggi(e.target.value)}
          className="border rounded p-2"
        />
        <button
          onClick={hitungBMI}
          className="bg-blue-500 text-white rounded p-2 hover:bg-blue-600"
        >
          Hitung
        </button>

        {hasil && (
          <div className="mt-4">
            <p>BMI: <b>{hasil.bmi}</b></p>
            <p>Kategori: <b>{hasil.kategori}</b></p>
          </div>
        )}
      </div>
    </div>
  );
}
