import { useState } from "react";
import Calendar from "react-calendar";
import "react-calendar/dist/Calendar.css";

export default function CalendarMenstruasi() {
  const [lastPeriod, setLastPeriod] = useState(null);
  const [prediksi, setPrediksi] = useState([]);

  const handleChange = (date) => {
    setLastPeriod(date);

    // Asumsi siklus 28 hari
    const prediksiDates = [];
    let next = new Date(date);

    for (let i = 0; i < 6; i++) {
      next = new Date(next.setDate(next.getDate() + 28));
      prediksiDates.push(new Date(next));
    }

    setPrediksi(prediksiDates);
  };

  const tileClassName = ({ date, view }) => {
    if (view === "month") {
      if (prediksi.find((d) => d.toDateString() === date.toDateString())) {
        return "bg-pink-300 rounded-full text-white";
      }
    }
  };

  return (
    <div className="p-6">
      <h1 className="text-2xl font-bold mb-4">Kalender Menstruasi</h1>
      <p className="mb-2">
        Pilih tanggal menstruasi terakhir untuk prediksi siklus berikutnya.
      </p>

      <Calendar onChange={handleChange} tileClassName={tileClassName} />

      {lastPeriod && (
        <div className="mt-4">
          <p>
            📅 Menstruasi terakhir:{" "}
            <b>{lastPeriod.toLocaleDateString("id-ID")}</b>
          </p>
          <p className="mt-2 font-semibold">Perkiraan siklus berikutnya:</p>
          <ul className="list-disc ml-6">
            {prediksi.map((d, i) => (
              <li key={i}>{d.toLocaleDateString("id-ID")}</li>
            ))}
          </ul>
        </div>
      )}
    </div>
  );
}
