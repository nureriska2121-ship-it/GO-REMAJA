import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import Navbar from "./components/Navbar";
import Artikel from "./pages/Artikel";
import QuizZone from "./pages/QuizZone";
import Konsultasi from "./pages/Konsultasi";
import CalendarMenstruasi from "./pages/CalendarMenstruasi";
import BMI from "./pages/BMI";

function App() {
  return (
    <Router>
      <Navbar />
      <div className="p-6">
        <Routes>
          <Route path="/artikel" element={<Artikel />} />
          <Route path="/kuis" element={<QuizZone />} />
          <Route path="/konsultasi" element={<Konsultasi />} />
          <Route path="/kalender" element={<CalendarMenstruasi />} />
          <Route path="/bmi" element={<BMI />} />
        </Routes>
      </div>
    </Router>
  );
}

export default App;
