import { Link } from "react-router-dom";
import { BookOpen, Gamepad2, MessageCircle, CalendarDays, Activity } from "lucide-react";

export default function Navbar() {
  return (
    <nav className="bg-blue-600 text-white px-6 py-3 flex justify-between items-center shadow-md">
      <h1 className="text-xl font-bold">Go Remaja</h1>
      <div className="flex gap-6">
        <Link to="/artikel" className="flex items-center gap-1 hover:text-gray-200">
          <BookOpen size={18}/> Artikel
        </Link>
        <Link to="/kuis" className="flex items-center gap-1 hover:text-gray-200">
          <Gamepad2 size={18}/> Quiz Zone
        </Link>
        <Link to="/konsultasi" className="flex items-center gap-1 hover:text-gray-200">
          <MessageCircle size={18}/> Konsultasi
        </Link>
        <Link to="/kalender" className="flex items-center gap-1 hover:text-gray-200">
          <CalendarDays size={18}/> Kalender
        </Link>
        <Link to="/bmi" className="flex items-center gap-1 hover:text-gray-200">
          <Activity size={18}/> BMI
        </Link>
      </div>
    </nav>
  );
}
